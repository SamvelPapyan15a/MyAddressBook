﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyAddressBook.ViewModels
{
    public class SearchInput
    {
        public string Request { get; set; }
    }
}
