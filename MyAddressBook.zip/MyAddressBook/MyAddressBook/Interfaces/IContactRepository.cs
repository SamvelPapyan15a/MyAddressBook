﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MyAddressBook.Models;

namespace MyAddressBook.Interfaces
{
    public interface IContactRepository
    {
        IEnumerable<Contact> Contacts { get; }
    }
}
