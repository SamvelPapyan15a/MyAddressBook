﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MyAddressBook.Models;
using MyAddressBook.Interfaces;

namespace MyAddressBook.Repositories
{
    public class EFContactRepository : IContactRepository
    {
        private ApplicationDbContext _context;
        public EFContactRepository(ApplicationDbContext context) {
            _context = context;
        }

        public IEnumerable<Contact> Contacts => _context.Contacts;
    }
}
