﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace MyAddressBook.Migrations
{
    public partial class ContactBeta2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ImageURL",
                table: "Contacts");

            migrationBuilder.AddColumn<byte[]>(
                name: "Image",
                table: "Contacts",
                type: "varbinary(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Image",
                table: "Contacts");

            migrationBuilder.AddColumn<string>(
                name: "ImageURL",
                table: "Contacts",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
