﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MyAddressBook.Migrations
{
    public partial class Contact3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Phone3",
                table: "Contacts",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Phone3",
                table: "Contacts");
        }
    }
}
