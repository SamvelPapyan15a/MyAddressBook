﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MyAddressBook.Repositories;
using MyAddressBook.Models;
using MyAddressBook.ViewModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.ViewComponents;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System.Text.RegularExpressions;
using System.IO;


namespace MyAddressBook.Controllers
{
    [ViewComponent(Name = "HybridComponent")]
    public class ContactController : Controller
    {
        ApplicationDbContext _context;
        IWebHostEnvironment _appEnv;
        public ContactController(ApplicationDbContext context, IWebHostEnvironment appEnv) {
            _context = context;
            _appEnv = appEnv;
        }
        public async Task<IActionResult> Index()
        {
            int number = 1;
            foreach (var item in _context.Contacts) {
                item.ContactNumber = number++;
            }
            await _context.SaveChangesAsync();
            return View(_context.Contacts.ToList());
        }
        public IActionResult Create() {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(ContactViewModel contactViewModel) {
            Contact contact = new Contact()
            {
                FullName = contactViewModel.FullName,
                Email = contactViewModel.Email,
                Phone = contactViewModel.Phone1,
                Phone2 = contactViewModel.Phone2,
                Phone3 = contactViewModel.Phone3,
                Comment = contactViewModel.Comment,
                PhysicalAddress = contactViewModel.PhysicalAddress
            };
            if (!ModelState.IsValid)
            {
                return View();
            }
            if (contactViewModel.Image != null)
            {
                byte[] imageData = null;
                using (var binaryReader = new BinaryReader(contactViewModel.Image.OpenReadStream()))
                {
                    imageData = binaryReader.ReadBytes((int)contactViewModel.Image.Length);
                }
                contact.Image = imageData;
            }
            else {
                contact.Image = null;
            }
            _context.Contacts.Add(contact);
            _context.SaveChanges();
            return RedirectToAction("Index", "Contact");
        }

        public IActionResult Edit(int id) {
            Contact contact = _context.Contacts.Find(id);
            return View(contact);
        }
        [HttpPost]
        public IActionResult Edit(ContactViewModel cvm) {
            Contact contact = _context.Contacts.Find(cvm.ContactID);
            if (!ModelState.IsValid)
            {
                return View(contact);
            }
            contact.FullName = cvm.FullName;
            contact.Email = cvm.Email;
            contact.Phone = cvm.Phone1;
            contact.Phone2 = cvm.Phone2;
            contact.Phone3 = cvm.Phone3;
            contact.PhysicalAddress = cvm.PhysicalAddress;
            contact.Comment = cvm.Comment;
            if (cvm.Image != null) {
                byte[] imageData = null;
                using (var binaryReader = new BinaryReader(cvm.Image.OpenReadStream())) {
                    imageData = binaryReader.ReadBytes((int)cvm.Image.Length);
                }
                contact.Image = imageData;
            }
            _context.SaveChanges();
            return RedirectToAction("Index", "Contact");
        }
        public IActionResult Delete(int id) {
            _context.Contacts.Remove(_context.Contacts.Find(id));
            _context.SaveChanges();
            return RedirectToAction("Index", "Contact");
        }
        public IActionResult Single(int id) {
            Contact contact = _context.Contacts.Find(id);
            return View(contact);
        }
        [HttpPost]
        public IActionResult Search(SearchInput searchInput) {
            if (String.IsNullOrEmpty(searchInput.Request)) {
                searchInput.Request = "";
            }
            Regex regex = new Regex(searchInput.Request, RegexOptions.IgnoreCase);
            IEnumerable<Contact> contacts = _context.Contacts.ToList().Where(x =>
            (int.TryParse(searchInput.Request, out int num) && x.ContactNumber == int.Parse(searchInput.Request)) ||
            (x.FullName != null && regex.IsMatch(x?.FullName)) ||
            (x.Email != null && regex.IsMatch(x?.Email)) ||
            (x.Phone != null && regex.IsMatch(x?.Phone)) ||
            (x.PhysicalAddress != null &&regex.IsMatch(x?.PhysicalAddress))
            );
            return View(contacts);
        }
        public IViewComponentResult Invoke()
        {
            return new ViewViewComponentResult
            {
                ViewData = new ViewDataDictionary<SearchInput>(ViewData, new SearchInput())
            };
        }
    }
}
